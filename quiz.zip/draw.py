import matplotlib.pyplot as plot
import json

keyMaps = {
    'school': [
            './school.json', '海大', '山大青岛', '青科', '青农', '恒星学院', '青大', '其他'
    ],
    'sex': [
            './sex.json', '男', '女'
    ],
    'grade': [
            './grade.json', '大一', '大二', '大三', '大四', '其他'
    ],
    'major': [
            './major.json', '理科类', '工科类', '文史类', '社科类', '其他'
    ]
}

# 解决乱码问题
plot.rcParams['font.sans-serif'] = ['SimHei']
plot.rcParams['axes.unicode_minus'] = False


def handle_result(key):
    with open(keyMaps[key][0], 'r', encoding='utf-8') as j:
        source = json.load(j)
    # 遍历父key
    for item in source:
        plot.title(item)
        for quiz in source[item]:
            name = quiz['name']
            labels = quiz['map'].keys()
            values = quiz['map'].values()
            plot.title(keyMaps[key][int(item)] + ' ' + name)
            plot.pie(values, labels=labels, autopct='%1.1f%%', shadow=False, startangle=90)
            plot.savefig('./pie/' + keyMaps[key][int(item)] + '_' + name + '.png')
            plot.close('all')


handle_result('school')
handle_result('sex')
handle_result('grade')
handle_result('major')